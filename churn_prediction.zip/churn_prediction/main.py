
import pandas as pd
import numpy as np
import mysql.connector
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import warnings
warnings.filterwarnings("ignore")

# ===========================
# 1. Load Dataset
# ===========================
file_path = r"C:\Users\shame\Downloads\churn_prediction\Telco-Customer-Churn.csv"
df = pd.read_csv(file_path)

# ===========================
# 2. Data Preprocessing
# ===========================
print("Initial dataset shape:", df.shape)

# Convert TotalCharges to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df["TotalCharges"].fillna(df["TotalCharges"].median(), inplace=True)

# Encode target variable
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

print("Null values after cleaning:", df.isnull().sum().sum())

# ===========================
# 3. Exploratory Data Analysis (Optional - Visualization)
# ===========================
sns.countplot(x="Churn", data=df)
plt.title("Churn Distribution")
plt.show()

sns.boxplot(x="Churn", y="MonthlyCharges", data=df)
plt.title("Monthly Charges vs Churn")
plt.show()

# ===========================
# 4. Store Cleaned Data in MySQL
# ===========================
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",         # CHANGE THIS
        password="root",
        charset="utf8"  # CHANGE THIS
    )
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS churn_db")
    cursor.execute("USE churn_db")
    cursor.execute("DROP TABLE IF EXISTS customers")

    cursor.execute("""
    CREATE TABLE customers (
        customerID VARCHAR(20) PRIMARY KEY,
        gender VARCHAR(10),
        SeniorCitizen INT,
        Partner VARCHAR(5),
        Dependents VARCHAR(5),
        tenure INT,
        PhoneService VARCHAR(20),
        MultipleLines VARCHAR(30),
        InternetService VARCHAR(30),
        OnlineSecurity VARCHAR(30),
        OnlineBackup VARCHAR(30),
        DeviceProtection VARCHAR(30),
        TechSupport VARCHAR(30),
        StreamingTV VARCHAR(30),
        StreamingMovies VARCHAR(30),
        Contract VARCHAR(30),
        PaperlessBilling VARCHAR(5),
        PaymentMethod VARCHAR(50),
        MonthlyCharges FLOAT,
        TotalCharges FLOAT,
        Churn INT
    )
    """)
    for _, row in df.iterrows():
        sql = """INSERT INTO customers VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        cursor.execute(sql, tuple(row))
    conn.commit()
    print("Data successfully stored in MySQL database 'churn_db'")
except mysql.connector.Error as err:
    print(f"MySQL Error: {err}")

# ===========================
# 5. Model Building
# ===========================
# Drop ID column and encode categorical variables
X = df.drop(["customerID", "Churn"], axis=1)
X = pd.get_dummies(X, drop_first=True)
y = df["Churn"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print("Classification Report:")
print(classification_report(y_test, y_pred))

# ===========================
# 6. Save Predictions Back to MySQL (Optional)
# ===========================
pred_df = pd.DataFrame({"customerID": df.loc[y_test.index, "customerID"], "Churn_Prediction": y_pred})
try:
    cursor.execute("DROP TABLE IF EXISTS churn_predictions")
    cursor.execute("""
    CREATE TABLE churn_predictions (
        customerID VARCHAR(20) PRIMARY KEY,
        Churn_Prediction INT
    )
    """)
    for _, row in pred_df.iterrows():
        cursor.execute("INSERT INTO churn_predictions VALUES (%s, %s)", tuple(row))
    conn.commit()
    print("Predictions stored in MySQL table 'churn_predictions'")
except Exception as e:
    print("Skipping MySQL prediction storage:", e)

# ===========================
# 7. Connect Tableau
# ===========================
print("""
✅ Project Completed!
You can now connect Tableau to MySQL (churn_db database) to visualize:
- Churn Rate by Contract Type
- Tenure distribution of Churners vs Non-Churners
- Monthly Charges vs Churn
- Model Prediction Output (churn_predictions table)
""")